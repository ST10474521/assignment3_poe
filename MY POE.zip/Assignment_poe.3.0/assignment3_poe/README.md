# assignment3_poe
 
